<form role="form" method="POST" action="{{ route('shipments.store') }}" enctype="multipart/form-data">
	
	@csrf
	<input type="file" name="your_file">
	<input type="submit" name="submit">
</form>