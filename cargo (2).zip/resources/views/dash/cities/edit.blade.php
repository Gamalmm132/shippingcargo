@extends('adminlte::page')

@section('content')

          <div class="box box-warning" >
            <div class="box-header with-border">
              <h3 class="box-title"> Edit City</h3>
             
            </div>
            <div class="box-body">
<form   method="post" action="{{ route('cities.update',$city->id) }}" >
	@method('PUT')
  @csrf

    
  <div class="form-group">
    <label for="formGroupExampleInput">City Name</label>
    <input type="text" class="form-control" id="formGroupExampleInput" readonly="readonly" value="{{$city->name}}">
  </div>
   <div class="form-group">
    <label for="formGroupExampleInput">City Fee</label>
    <input type="text" class="form-control" id="formGroupExampleInput" name="fees" value="{{$city->fees}}">
  </div>

<div class="box-footer">
  <input type="submit" name="submit" value="  Update" class="btn btn-success btn-lg pull-right  ">
  </div>
  </form>
</div>
@stop