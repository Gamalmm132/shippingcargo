@extends('adminlte::page')



@section('content')


	{{-- expr --}}

<div style="page-break-after:always;">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">

      <div class="col-xs-12">
        @if ($shipment->status_name=='preparing')
          <button type="button" class="btn btn-warning pull-right " data-toggle="modal" data-target="#edit">Edit</button>
        @endif
         
        <h3 class="page-header">
          
          <small ><b>#{{$shipment->id}}</b></small>

        </h3>
      </div>
      <!-- /.col -->
    </div>
    
    <div class="row" >
      
  
       
        <div class="col-xs-12 table-responsive" >
          <table class="table " >
            @if ( Auth::user()->type=='admin')
              
           
            	<tr>
              <th>From</th>
              <td >{{$shipment->cbyn->fname}} {{$shipment->cbyn->lname}}</td>
              <th>#{{$shipment->cby}}</th>
              <td></td>
            </tr>
             @endif
            <tr>
              <th>To</th>
              <td colspan="3">{{$shipment->name}}</td>
            </tr>
            <tr>
              <th>Mobile:</th>
              <td colspan="3">{{$shipment->mobile}}</td>
            </tr>
            <tr>
              <th>District</th>   
              <td>{{$shipment->district}}</td>
                  <th>City:</th>
              <td>{{$shipment->city_name}}</td>
            </tr>
            <tr>
              <th >Address:</th>
              <td colspan="4">{{$shipment->address}}</td>
            </tr>
            
            
            <tr>
              <th>Note:</th>
              <td colspan="4">{{$shipment->comment}}</td>
            </tr>
            <tr>
              <th><p class="lead"><b>Net Amount:{{$shipment->netamount}}</b></p></th>
              <th><p class="lead"><b>Fees:{{$shipment->fees}}</b></p></th>
              <th><p class="lead"><b>Total Amount:{{$shipment->totalamount}}</b></p></th>
              
            </tr>
            @if ($collecs)
            @if ($collecs->collected==0)
            <tr>
              <th>Collected:</th>   
              <td>{{$collecs->created_at}}<b>By:</b>{{$collecs->cbyn->fname}}</td>
                  <th>Transferred:</th>
              <td>Not Yet</td>
            </tr>
            @elseif($collecs->collected==1)
            <tr>
              <th>Collected:</th>   
              <td>{{$collecs->collected_at}}<b>By:</b>{{$collecs->collecs->fname}}</td>
                  <th>Transferred:</th>
              <td>{{$collecs->transferred_at}}<b>By:</b>{{$collecs->transfs->fname}}</td>
            </tr>
            @endif
            @else
            <tr>
              <th>Collected:</th>   
              <td>Not Yet</td>
                  <th>Transferred:</th>
               <td>Not Yet</td>
            </tr>

            @endif
            

          </table>
       
      </div>
      <!-- /.col -->
    
      <!-- /.col -->
    </div>

    <!-- /.row -->
     <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Status</th>
              <th>Comment</th>
              <th>by</th>
              <th>Date</th>
             
            </tr>
            </thead>
            <tbody>
              @foreach ( $status as $stat)
            <tr>

                
            
              <td>{{$stat->status_name}}</td>
              <td>{{$stat->comment}}</td>
              <td>{{$stat->cbyn->fname}}</td>
              <td>{{$stat->created_at}}</td>
              
            </tr>
              @endforeach
            </tbody>
          </table>
        </div>
        
      </div>

    <!-- Table row -->
 
    <!-- /.row -->


    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
 @if ($shipment->status_name=='preparing')
<div class="modal fade" id="edit">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Shipment</h4>
              </div>
              <form role="form" method="POST" action="{{ route('shipments.update',$shipment->id) }}" >
                @csrf
                @method('PUT')
              <div class="modal-body">
               <div class="form-group">
            <label for="recipient-name" class="col-form-label">To</label>
            <input type="text" class="form-control" id="recipient-name" value="{{$shipment->name}}" name="name">
               </div>
               <div class="form-group">
            <label for="recipient-name" class="col-form-label">Mobile</label>
            <input type="text" class="form-control" id="recipient-name" value="{{$shipment->mobile}}"  name="mobile">
               </div>
               <div class="form-group">
            <label for="recipient-name" class="col-form-label">Address</label>
            <input type="text" class="form-control" id="recipient-name" value="{{$shipment->address}}"  name="address">
               </div>

               <div class="row">
            <div class="col-xs-6">
                <label for="recipient-name" class="col-form-label">District</label>
                  <input type="text" name="district" class="form-control" value="{{$shipment->district}}" >
                </div>
                <div class="col-xs-6">
                  <label for="recipient-name" class="col-form-label">City</label>
                  <select class="form-control" name="city">
                    <option></option>
                    @foreach ($cities as $city)
                      <option value="{{$city->id}}"
                        @if ($city->id==$shipment->city_id)
                          selected="selected" 
                        @endif>{{$city->name}}</option>
                    @endforeach
                  </select>
                </div>
               </div>
               <div class="form-group">
            <label for="recipient-name" class="col-form-label">Note</label>
            <input type="text" class="form-control" id="recipient-name" value="{{$shipment->comment}}"  name="comment">
               </div>
               <div class="form-group">
            <label for="recipient-name" class="col-form-label">Total Amount</label>
            <input type="number" class="form-control" id="recipient-name" value="{{$shipment->totalamount}}"  name="totalamount">
               </div>
                
               
               
              </div>
              <div class="modal-footer">
                <input type="submit" class="btn btn-warning" value="Edit ">
               
              </div>
          </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        @endif
@stop
