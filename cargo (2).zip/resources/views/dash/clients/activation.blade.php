@extends('adminlte::page')

@section('content')

              

          <div class="box box-warning" >
            <div class="box-header with-border">
              <h3 class="box-title"> Activating Client</h3>
              
            </div>
              <form role="form" method="POST" action="{{ route('manageclients.update',$client->id) }}">
                @csrf
                @method('PUT')
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Client Shipping Code</label>
                  <input type="text" class="form-control" required="required" id="exampleInputEmail1"  name=" shipping_code">
                </div>
              
              <div class="box-body">
<table id="datat" class="table"  style="background-color: white">
  <thead class="thead-dark">
    <tr>
      
      <th scope="col">City</th>

      <th scope="col">Fees</th>
      

    </tr>
  </thead>
  <tbody>
    @foreach ($cities as $city)
    
  
    <tr>
 
      <th scope="row"> {{$city->name}}</th>
      <th scope="row"><input type="number" name="fees[{{$city->id}}]" min="0" required="required" value="{{$city->fees}}"> </th>
     
        
     
    </tr>
      @endforeach
</tbody>
</table>
              </div>



              <div class="box-footer">
             <input type="submit" class="btn btn-success " value="Activate">
              </div>
            </form>
          </div>
          @stop
@push('css')
<style >
	
	body{background-color: white !important}

</style>

@endpush
@section('js')
<script >
	$(document).ready(function() {
    $('#datat').DataTable( {
  
});
} );
</script>
@stop