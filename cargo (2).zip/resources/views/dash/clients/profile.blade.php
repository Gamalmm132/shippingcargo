@extends('adminlte::page')

@section('content')



@if($errors->count()>0)
<div class="callout callout-danger">
               


   @foreach ($errors->all() as $error)
  
 <h4>{{ $error }}</h4>
  @endforeach
  </div>
@endif

@if (\Session::has('success'))
<div class="callout callout-success">
               



  
 <h4>{!! \Session::get('success') !!}</h4>

  </div>
@endif


      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-warning">

            <div class="box-body box-profile">
              

              <h3 class="profile-username text-center">{{$user->fname}} {{$user->lname}}</h3>

              <p class="text-muted text-center">#{{$user->id}}</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Target Per Month</b> <a class="pull-right text-yellow">{{$user->shippment_count}}</a>
                </li>
                <li class="list-group-item">
                  <b>Shpments This Month</b> <a class="pull-right  text-yellow">{{$shipmentc->count()}}</a>
                </li>
                
                <li class="list-group-item">
                  <b>All Shipments</b> <a class="pull-right  text-yellow">{{$user->ships->count()}}</a>
                </li>
                <li class="list-group-item">
                  <b>Current Balance</b> <a class="pull-right  text-yellow">{{$wallet->sum('amount')}}</a>
                </li>
              </ul>

              <a href="{{ route('wallet.index') }}" class="btn btn-warning btn-block"><b>Go To Wallet</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->

            <div class="box-body">
               <strong><i class="fa fa-user margin-r-5"></i> Username</strong>

              <p class="text-muted">
                {{$user->username}}
              </p>

              <hr>

              <strong><i class="fa fa-at margin-r-5"></i> Email</strong>

              <p class="text-muted">
                {{$user->email}}
              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Address</strong>

              <p class="text-muted">{{$user->profs->address}}</p>

              <hr>

              <strong><i class="fa fa-phone margin-r-5"></i> mobile</strong>

              <p class="text-muted">{{$user->mobile}}</p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i> Shipping Code</strong>

              <p>{{$user->profs->shipping_code}}</p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#profile" data-toggle="tab">Profile</a></li>
              <li ><a href="#security" data-toggle="tab">Security</a></li>
              <li ><a href="#wallet" data-toggle="tab">Wallet</a></li>
              <li ><a href="#shipments" data-toggle="tab">Shipments</a></li>
              
              
              
            </ul>
            <div class="tab-content">
              
              

              <div class="tab-pane active"  id="profile">
                <form class="form-horizontal" method="post" action="{{ route('profile.edit',['id'=>$user->id]) }}">
                 
                  @csrf
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Page Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->page_name}}" name="page_name" >
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Mobile 2</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="mobile" value="{{$user->profs->mobile}}">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Address</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="address" value="{{$user->profs->address}}">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">City</label>

                    <div class="col-sm-10">
                      <select class="form-control"  name="city_id">
                        <option > Select City</option>
                        @foreach ($cities as $city)
                          <option value="{{$city->id}}" @if ($user->profs->city_id ==$city->id)
                           selected="selected"
                          @endif > {{$city->name}}</option>
                        @endforeach
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">District</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->district}}"  name="district">
                    </div>
                  </div>
                 
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Bank Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->bank_name}}" name="bank_name" >
                    </div>
                  </div>
                   <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Bank Account</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->bank_account}}" name="bank_account" >
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Shipping Code</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->shipping_code}}" name="shipping_code" >
                    </div>
                  </div>
                
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <input type="submit" value="Update" class="btn btn-danger">
                    </div>
                  </div>
                </form>
              </div>
              <div class="tab-pane "  id="security">
                <form class="form-horizontal" method="post" action="{{ route('profile.update',['user_id'=>$user->id,'id'=>$user->id]) }}">
                 @method('PUT')
                  @csrf
                  
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">First Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="fname" value="{{$user->fname}}">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Last Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="lname" value="{{$user->lname}}">
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Username</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->username}}"  name="username">
                    </div>
                  </div>
                 
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Mobile</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->mobile}}" name="mobile" >
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control"  value="{{$user->email}}" name="Email" >
                    </div>
                  </div>
                   
                    
                 
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Status</label>

                    <div class="col-sm-10">
                      @if ($user->status !='pending')
                      <select class="form-control"  name="status">
                        <option > Select Status</option>
                        <option value="activated" @if ($user->status =='activated')
                           selected="selected"
                          @endif > Active</option>
                          <option value="disabled" @if ($user->status =='disabled')
                           selected="selected"
                          @endif > Disabled</option>
                          <option value="suspended" @if ($user->status =='suspended')
                           selected="selected"
                          @endif > Suspended</option>
                      </select>
                      @else 
                    <a href="{{ route('manageclients.show',$user->id) }}" class="btn btn-success" >verify</a>
                    @endif
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <input type="submit" value="Update" class="btn btn-danger">
                    </div>
                  </div>
                </form>
              </div>
              <div class="tab-pane "  id="wallet">
                <table id="walle" class="display compact datatable" style="width:100%">
        <thead>
            <tr>
                <th>Code</th>
                <th>Amount</th>
                <th>Collected</th>
                <th>Transferred At</th>
            </tr>
        </thead>
        <tbody>
           @foreach ($wallets as $shipment)
            <tr>
            
                <a href="{{ route('shipments.show',$shipment->id) }}" >{{$shipment->id}}</a>
                <td>{{$shipment->amount}}</td>
                <td>{{$shipment->collected_at}}</td>
                <td>@if ($shipment->transferred_at !=NULL)
                  {{$shipment->collected_at}}
                  @else
                  Not Yet
                @endif</td>
                
                
            </tr>
          @endforeach
          </tbody>
        </table>
              </div>

               <div class="tab-pane "  id="shipments">
                <table id="ships" class="display compact datatable" style="width:100%">
        <thead>
            <tr>
                
                <th>Shipment Code</th>
                <th>Name</th>
                <th>Status</th>
                <th>Date</th>
                
            </tr>
        </thead>
        <tbody>
          @foreach ($shipments as $shipment)
            <tr>
               <td><a href="{{ route('shipments.show',$shipment->id) }}" >{{$shipment->id}}</a></td>
                <td>{{$shipment->name}}</td>
                <td>{{$shipment->stats->last()->status_name}}</td>
                <td>{{$shipment->stats->last()->created_at}}</td>
                
            </tr>
          @endforeach
            
          </tbody>
        </table>
              </div>

              
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

 

@stop

@push('css')
<style type="text/css">
  .nav-tabs-custom > .nav-tabs > li.active{border-top-color: #e08e0b;}
	#datatble_filter{display: none}
	#datatble_length{float: right;}
	.cregex,.csmart{display: none}
	#stable tr td {font-weight: bold}
	#stable tr td input , #stable tr td select{width: 200px}
	.input-group-append{position: absolute !important;}
	.input-group-append button{background-color: white; height:30px}
	.input-group-append button i{padding: auto}
</style>

<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
<link href=" https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css" rel="stylesheet">

<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
@endpush
@push('js')
<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
       
  

       <script src="https://code.jquery.com/jquery-3.3.1.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js" type="text/javascript"></script>


      <script src=" https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/select/1.3.0/js/dataTables.select.min.js" type="text/javascript"></script>




<script >
$(document).ready(function() {
    $('#walle').DataTable();
    $('#ships').DataTable();
} );
</script>
@endpush