@extends('adminlte::page')

@section('content')

<div class="box box-warning" >
            <div class="box-header with-border" >
                
               <button type="button" class="btn btn-box-tool" data-widget="collapse"><h3 class="box-title">Clients</h3>
                </button>
          
             
                
                
               
                 
             
            </div>
            <div class="box-body">

<table id="datatble"  class="table table-striped table-bordered display" style="width:100%">
        <thead>
            <tr>
                
                
                <th>Name</th>
                <th>Page Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Shippments</th>
                <th>Status</th>
                <th>Date</th>
                

            </tr>
        </thead>

        <tbody>
            @foreach ($users as $user)
                <tr>
                
                <td><a href="{{ route('profile.show',$user->id) }}" >{{$user->fname}} {{$user->lname}}</td>
                   <td>{{$user->profs->page_name}}</td>
                <td>{{$user->mobile}}</td>
                <td>{{$user->email}}</td>
                <td>{{$user->shipments}}</td>
                <td>@if ($user->status=="pending")
                    <a href="{{ route('manageclients.show',$user->id) }}" class="btn btn-success" >verify</a>
                    @else
                    {{$user->status}}
                @endif</td>
                <td>{{$user->created_at}}</td>
               
                
                
            </tr>
            @endforeach
            
        </tbody>
    </table>
    

</div>

<div class="box-footer">

  </div>


</div>

@stop
@section('js')

<script >
  
    function filterGlobal () {
    $('#datatble').DataTable().search(
        $('#global_filter').val(),
        $('#global_regex').prop('checked'),
        $('#global_smart').prop('checked')
    ).draw();
}
 
function filterColumn ( i ) {
    $('#datatble').DataTable().column( i ).search(
        $('#col'+i+'_filter').val(),
        $('#col'+i+'_regex').prop('checked'),
        $('#col'+i+'_smart').prop('checked')
    ).draw();
}
 
$(document).ready(function() {
    $('#datatble').DataTable({
        "scrollX": true,
         dom: 'lBfrtip',
         buttons: [
            'copy',
            'csv',
            'excel',
            'pdf',
            'print'
        ],
        select: true, "order": [[ 0, "desc" ]],
        
       

});
     $('#print').on( 'click', function (e) {
      
 
        // Get the column API object
        var column = table.column(8);
 
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
    $('.rsell', this).css('background-color')
    var table = $('#advtable').DataTable();
 
    $('#advtable tbody').on( 'click', 'tr', function () {
        $(this).toggleClass('selected');
    } );
 
    $('input.global_filter').on( 'keyup click', function () {
        filterGlobal();
    } );
 
    $('input.column_filter').on( 'keyup click', function () {
        filterColumn( $(this).parents('tr').attr('data-column') );
    } );
    
     var table = $('#datatble').DataTable();

     table.columns(3).indexes().flatten().each( function ( i ) {
    var column = table.column( i );
    var select = $('#city')
        
        .on( 'change', function () {
           
            var val = $.fn.dataTable.util.escapeRegex(
                $(this).val()
            );
 
            column
                .search( val ? '^'+val+'$' : '', true, false )
                .draw();
        } );
 
    column.data().unique().sort().each( function ( d, j ) {
        select.append( '<option value="'+d+'">'+d+'</option>' )
    } );
} );
 
table.columns(6).indexes().flatten().each( function ( i ) {
    var column = table.column( i );
    var select = $('#status')
        
        .on( 'change', function () {
           
            var val = $.fn.dataTable.util.escapeRegex(
                $(this).val()
            );
 
            column
                .search( val ? '^'+val+'$' : '', true, false )
                .draw();
        } );
 
    column.data().unique().sort().each( function ( d, j ) {
        select.append( '<option value="'+d+'">'+d+'</option>' )
    } );
} );
} );
    

    
</script>
@stop
@push('js')
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
       
  

       <script src="https://code.jquery.com/jquery-3.3.1.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js" type="text/javascript"></script>


      <script src=" https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/select/1.3.0/js/dataTables.select.min.js" type="text/javascript"></script>




@endpush
@push('css')
<style type="text/css">
    #datatble_filter{display: none}
    #datatble_length{float: right;}
    .cregex,.csmart{display: none}
    #stable tr td {font-weight: bold}
    #stable tr td input , #stable tr td select{width: 200px}
    .input-group-append{position: absolute !important;}
    .input-group-append button{background-color: white; height:30px}
    .input-group-append button i{padding: auto}
</style>
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
<link href=" https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css" rel="stylesheet">

    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">



@endpush