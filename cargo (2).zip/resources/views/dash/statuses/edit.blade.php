@extends('adminlte::page')

@section('content')

          <div class="box box-warning" >
            <div class="box-header with-border">
              <h3 class="box-title"> Edit status</h3>
             
            </div>
            <div class="box-body">
<form   method="post" action="{{ route('statusname.update',$statusname->id) }}" >
	@method('PUT')
  @csrf

    
  <div class="form-group">
    <label for="formGroupExampleInput">status Name</label>
    <input type="text" class="form-control" id="formGroupExampleInput" name="name" value="{{$statusname->name}}">
  </div>
   

<div class="box-footer">
  <input type="submit" name="submit" value="  Update" class="btn btn-success btn-lg pull-right  ">
  </div>
  </form>
</div>
@stop