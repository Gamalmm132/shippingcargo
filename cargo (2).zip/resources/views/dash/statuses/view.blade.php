@extends('adminlte::page')




@section('content')
          <div class="box box-warning" >

            <div class="box-header with-border">
              <h3 class="box-title">statuses</h3>
              <button type="button" class="btn btn-success pull-right " data-toggle="modal" data-target="#exampleModal">Add status</button>
            </div>
            <div class="box-body">
   <table id="datat" class=" table table-bordered"  style="background-color: white">
  <thead class="thead-dark">
    <tr>
      
      <th scope="col">status</th>
     
     
      
    </tr>
  </thead>
  <tbody>
    @foreach ($statusname as $statusnames)
    
  
    <tr>
      <th scope="row"><a href="{{ route('statusname.edit',$statusnames->id) }}"> {{$statusnames->name}}</a></th>
           
      

    </tr>
      @endforeach
</tbody>
</table>
</div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" >
        <h'admin' class="modal-title" id="exampleModalLabel" >Create status</h'admin'>

      </div>
       <form method="POST" action="{{ route('statusname.store') }}">
       	@csrf
      <div class="modal-body" >
       
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">status Name</label>
            <input type="text" class="form-control" id="recipient-name" name="name">
          </div>
         

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input   type="submit" class="btn btn-primary" value="Create">
      </div>

        </form>
    </div>
  </div>
</div>
@stop
@push('css')
<style >
	body{background-color: white !important}

</style>

@endpush
@section('js')
<script >
	$(document).ready(function() {
    $('#datat').DataTable( {
   "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Arabic.json"
        }, "searching": false,
} );
</script>
@stop