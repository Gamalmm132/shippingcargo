@extends('adminlte::page')




@section('content')
          <div class="box box-warning" >

            <div class="box-header with-border">
              <h3 class="box-title">zones</h3>
              <button type="button" class="btn btn-success pull-right " data-toggle="modal" data-target="#exampleModal">Add zone</button>
            </div>
            <div class="box-body">
   <table id="datat" class=" table table-bordered"  style="background-color: white">
  <thead class="thead-dark">
    <tr>
      
      <th scope="col">zone</th>
      <th scope="col">Fee</th>
      <th scope="col">delete</th>
      
    </tr>
  </thead>
  <tbody>
    @foreach ($zones as $zone)
    
  
    <tr>
      <th scope="row"><a href="{{ route('zones.edit',$zone->id) }}"> {{$zone->name}}</a></th>
      <th >  {{$zone->fees}}</th>
      <th>      <form action="{{ route('zones.destroy',$zone->id) }}" method="POST">
          @method('DELETE')
        @csrf
        
        <input type="submit"  class="btn btn-lg btn-danger" value="Delete" onclick="return confirm('تأكيد الالغاء');">
      </form>
    </th>
     
      

    </tr>
      @endforeach
</tbody>
</table>
</div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" >
        <h'admin' class="modal-title" id="exampleModalLabel" >Create zone</h'admin'>

      </div>
       <form method="POST" action="{{ route('zones.store') }}">
       	@csrf
      <div class="modal-body" >
       
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">zone Name</label>
            <input type="text" class="form-control" id="recipient-name" name="name">
          </div>
           <div class="form-group">
            <label for="recipient-name" class="col-form-label">zone Fee</label>
            <input type="text" class="form-control" id="recipient-name" name="fees">
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input   type="submit" class="btn btn-primary" value="Create">
      </div>

        </form>
    </div>
  </div>
</div>
@stop
@push('css')
<style >
	body{background-color: white !important}

</style>

@endpush
@section('js')
<script >
	$(document).ready(function() {
    $('#datat').DataTable( {
   "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Arabic.json"
        }, "searching": false,
} );
</script>
@stop