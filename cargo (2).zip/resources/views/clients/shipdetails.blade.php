@extends('adminlte::page')



@section('content')


	{{-- expr --}}

<div style="page-break-after:always;">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12">
        <h3 class="page-header">
          
          <small ><b>#{{$shipment->id}}</b></small>
        </h3>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row" >
      
      <!-- /.col -->
       
        <div class="col-xs-12 table-responsive" >
          <table class="table " >
            @if ( Auth::user()->type=='admin')
              {{-- expr --}}
           
            	<tr>
              <th>From</th>
              <td >{{$shipment->cbyn->fname}} {{$shipment->cbyn->lname}}</td>
              <th>#{{$shipment->cby}}</th>
              <td></td>
            </tr>
             @endif
            <tr>
              <th>To</th>
              <td colspan="3">{{$shipment->name}}</td>
            </tr>
            <tr>
              <th>Mobile:</th>
              <td colspan="3">{{$shipment->mobile}}</td>
            </tr>
            <tr>
              <th>District</th>   
              <td>{{$shipment->district}}</td>
                  <th>City:</th>
              <td>{{$shipment->city_name}}</td>
            </tr>
            <tr>
              <th >Address:</th>
              <td colspan="4">{{$shipment->address}}</td>
            </tr>
            
            
            <tr>
              <th>Note:</th>
              <td colspan="4">{{$shipment->comment}}</td>
            </tr>
            @if ($collecs)
            @if ($collecs->collected==0)
            <tr>
              <th>Collected:</th>   
              <td>{{$collecs->created_at}}</td>
                  <th>Transferred:</th>
              <td>Not Yet</td>
            </tr>
            @elseif($collecs->collected==1)
            <tr>
              <th>Collected:</th>   
              <td>{{$collecs->collected_at}}</td>
                  <th>Transferred:</th>
              <td>{{$collecs->transferred_at}} </td>
            </tr>
            @endif
            @else
            <tr>
              <th>Collected:</th>   
              <td>Not Yet</td>
                  <th>Transferred:</th>
               <td>Not Yet</td>
            </tr>

            @endif
            <tr>
              <th><p class="lead"><b>Net Amount:{{$shipment->netamount}}</b></p></th>
              <th><p class="lead"><b>Fees:{{$shipment->fees}}</b></p></th>
              <th><p class="lead"><b>Total Amount:{{$shipment->totalamount}}</b></p></th>
              
            </tr>
            
          </table>
       
      </div>
      <!-- /.col -->
    
      <!-- /.col -->
    </div>

    <!-- /.row -->
     <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Status</th>
              <th>Comment</th>
              <th>Date</th>
             
            </tr>
            </thead>
            <tbody>
              @foreach ( $status as $stat)
            <tr>

                
            
              <td>{{$stat->status_name}}</td>
              <td>{{$stat->comment}}</td>
              <td>{{$stat->created_at}}</td>
              
            </tr>
              @endforeach
            </tbody>
          </table>
        </div>
        
      </div>

    <!-- Table row -->
 
    <!-- /.row -->


    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>


@stop
