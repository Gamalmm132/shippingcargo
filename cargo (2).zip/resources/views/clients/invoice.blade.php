@extends('adminlte::master')

@section('adminlte_css')
    <link rel="stylesheet" href="{{ asset('vendor/adminlte/vendor/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    @yield('css')
    <style type="text/css">
        body{background:white !important;}
        .pace{display: none !important}
        @media print{
  
.page-header {
    padding-bottom: 9px;
    margin: 40px 0 20px;
    border-bottom: 1px solid #eee;
}
   .table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
    border-top: 1px solid #dbdbdb;

}
.invoice{border: 1px solid #dbdbdb;}}
    </style>
@stop



@section('body')

@foreach ($shipments as $shipment)
	{{-- expr --}}

<div class="wrapper" style="page-break-after:always;">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12">
        <h3 class="page-header">
          <img  src="{{ asset('logo.png') }}" style="height: 30px">
          <small class="pull-right"><b>#{{$shipment->id}}</b></small>
        </h3>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row" >
      
      <!-- /.col -->
      <div class="col-xs-12  " >
       
        <div class="table-responsive" >
          <table class="table " style="table-layout: fixed;width: 90%">
            <tr>
            	<tr>
              <th>From</th>
              <td colspan="3">{{$shipment->cbyn->fname}} {{$shipment->cbyn->lname}}</td>
              <td rowspan="5">        {!! QrCode::size(180)->generate($shipment->id); !!}
</td>
            </tr>
            <tr>
              <th>To</th>
              <td colspan="3">{{$shipment->name}}</td>
            </tr>
            <tr>
              <th>Mobile:</th>
              <td colspan="3">{{$shipment->mobile}}</td>
            </tr>
            <tr>
              <th>District</th>
              <td>{{$shipment->district}}</td>
                  <th>City:</th>
              <td>{{$shipment->city_name}}</td>
            </tr>
            <tr>
              <th >Address:</th>
              <td colspan="4">{{$shipment->address}}</td>
            </tr>
            
            
            <tr>
              <th>Description:</th>
              <td colspan="4">{{$shipment->comment}}</td>
            </tr>
            <tr>
              <th><p class="lead"><b>Signature:</b></p></th>
              <td colspan="2"></td>
                  <th> <p class="lead"><b>Amount:{{$shipment->totalamount}}</b></p>
</th>
              <td  > 
</td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.col -->
    
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->
 
    <!-- /.row -->

    
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
@endforeach

@stop
<script type="text/javascript"> 

  window.addEventListener("ready", window.print());
</script>