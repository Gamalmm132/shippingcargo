@extends('adminlte::page')

@section('content')



@if($errors->count()>0)
<div class="callout callout-danger">
               


   @foreach ($errors->all() as $error)
  
 <h4>{{ $error }}</h4>
  @endforeach
  </div>
@endif

@if (\Session::has('success'))
<div class="callout callout-success">
               



  
 <h4>{!! \Session::get('success') !!}</h4>

  </div>
@endif


      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-warning">

            <div class="box-body box-profile">
              

              <h3 class="profile-username text-center">{{$user->fname}} {{$user->lname}}</h3>

              <p class="text-muted text-center">#{{$user->id}}</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Target Per Month</b> <a class="pull-right text-yellow">{{$user->shippment_count}}</a>
                </li>
                <li class="list-group-item">
                  <b>Shpments This Month</b> <a class="pull-right  text-yellow">{{$shipmentc->count()}}</a>
                </li>
                
                <li class="list-group-item">
                  <b>All Shipments</b> <a class="pull-right  text-yellow">{{$user->ships->count()}}</a>
                </li>
                <li class="list-group-item">
                  <b>Current Balance</b> <a class="pull-right  text-yellow">{{$wallet->sum('amount')}}</a>
                </li>
              </ul>

              <a href="{{ route('wallet.index') }}" class="btn btn-warning btn-block"><b>Go To Wallet</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->

            <div class="box-body">
               <strong><i class="fa fa-user margin-r-5"></i> Username</strong>

              <p class="text-muted">
                {{$user->username}}
              </p>

              <hr>

              <strong><i class="fa fa-at margin-r-5"></i> Email</strong>

              <p class="text-muted">
                {{$user->email}}
              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Address</strong>

              <p class="text-muted">{{$user->profs->address}}</p>

              <hr>

              <strong><i class="fa fa-phone margin-r-5"></i> mobile</strong>

              <p class="text-muted">{{$user->mobile}}</p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i> Shipping Code</strong>

              <p>{{$user->profs->shipping_code}}</p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#profile" data-toggle="tab">Profile</a></li>
              <li ><a href="#password" data-toggle="tab">Password</a></li>
              
              
            </ul>
            <div class="tab-content">
              
              

              <div class="tab-pane active"  id="profile">
                <form class="form-horizontal" method="post" action="{{ route('editprofile') }}">
                  @csrf
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Page Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->page_name}}" name="page_name" >
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Mobile 2</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="mobile" value="{{$user->profs->mobile}}">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Address</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="address" value="{{$user->profs->address}}">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">City</label>

                    <div class="col-sm-10">
                      <select class="form-control"  name="city_id">
                        <option > Select City</option>
                        @foreach ($cities as $city)
                          <option value="{{$city->id}}" @if ($user->profs->city_id ==$city->id)
                           selected="selected"
                          @endif > {{$city->name}}</option>
                        @endforeach
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">District</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->district}}"  name="district">
                    </div>
                  </div>
                 
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Bank Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->bank_name}}" name="bank_name" >
                    </div>
                  </div>
                   <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Bank Account</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control"  value="{{$user->profs->bank_account}}" name="bank_account" >
                    </div>
                  </div>
                
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <input type="submit" value="Update" class="btn btn-danger">
                    </div>
                  </div>
                </form>
              </div>
              <div class="tab-pane "  id="password">
                <form class="form-horizontal" method="post" action="{{ route('changepass') }}">
                  @csrf
                  
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Password</label>

                    <div class="col-sm-10">
                      <input type="password" name="password" class="form-control" >
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Retypr Password</label>

                    <div class="col-sm-10">
                      <input type="password" name="password_confirmation" class="form-control" >
                    </div>
                  </div>
                  
                
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <input type="submit" value="Change Password" class="btn btn-danger">
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

 

@stop

@push('css')
<style type="text/css">
  .nav-tabs-custom > .nav-tabs > li.active{border-top-color: #e08e0b;}
	#datatble_filter{display: none}
	#datatble_length{float: right;}
	.cregex,.csmart{display: none}
	#stable tr td {font-weight: bold}
	#stable tr td input , #stable tr td select{width: 200px}
	.input-group-append{position: absolute !important;}
	.input-group-append button{background-color: white; height:30px}
	.input-group-append button i{padding: auto}
</style>


@endpush