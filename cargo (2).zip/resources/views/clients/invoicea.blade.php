@extends('adminlte::master')

@section('adminlte_css')
    <link rel="stylesheet" href="{{ asset('vendor/adminlte/vendor/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    @yield('css')
    <style type="text/css">
        body{background:white !important;}

    </style>
@stop



@section('body')


<div class="wrapper">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12">
        <h2 class="page-header">
          <img  src="{{ asset('logo.png') }}" style="height: 20px">
          <small class="pull-right">Date: 2/10/2014</small>
        </h2>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
      <div class="col-sm-4 invoice-col">
        Order From
        <address>
          <strong>Admin, Inc.</strong><br>
          795 Folsom Ave, Suite 600
          San Francisco, CA 94107
          Phone: (804) 123-5432
          Email: info@almasaeedstudio.com
        </address>
      </div>
      <!-- /.col -->
      <div class="col-sm-5 invoice-col">
        Ship To:<b>test</b>
        <div class="table-responsive">
          <table class="table">
            <tr>
              <th style="width:20%">Address:</th>
              <td>795 Folsom Ave, Suite 600
          San Francisco, CA 94107
          Phone: (804) 123-5432
          Email: info@almasaeedstudio.com</td>
            </tr>
            <tr>
              <th>District</th>
              <td>$10.34</td>
            </tr>
            <tr>
              <th>City:</th>
              <td>$5.80</td>
            </tr>
            <tr>
              <th>Mobile:</th>
              <td>$265.24</td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.col -->
      <div class="col-sm-3 invoice-col">
        {!! QrCode::size(150)->generate('hi'); !!}
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->
 
    <!-- /.row -->

    <div class="row">
      <!-- accepted payments column -->
      <div class="col-xs-6">
        <p class="lead"><b>Signature:</b></p>
        
      </div>
      <!-- /.col -->
      <div class="col-xs-6">
        <p class="lead"><b>Amount:</b></p>

        
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->


@stop
<script type="text/javascript"> 
  window.addEventListener("load", window.print());
</script>