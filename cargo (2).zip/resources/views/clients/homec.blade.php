@extends('adminlte::page')

@section('content')
<div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>150</h3>

              <p>New Orders</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>53<sup style="font-size: 20px">%</sup></h3>

              <p>Bounce Rate</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>44</h3>

              <p>User Registrations</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>65</h3>

              <p>Unique Visitors</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
<div class="box box-warning" >
            <div class="box-header with-border" >
               <button type="button" class="btn btn-box-tool" data-widget="collapse"><h3 class="box-title">Shipments</h3>
                </button>
          
                <button class="btn  btn-danger pull-right" type="button" data-toggle="collapse" data-target="#searchdiv" aria-expanded="false" aria-controls="searchdiv" style="margin:0px 3px"><h3 class="box-title" ><i class="ion ion-search"></i></h3></button>
                <button type="button" style="margin:0px 3px" class="btn  btn-warning pull-right" data-widget="collapse"><h3 class="box-title"><i class="ion ion-printer"></i></h3>
                </button>
             
            </div>
            <div class="box-body">

            	<div class="col-lg-12  collapse" id="searchdiv" style="border-bottom: black 1px solid; margin-bottom: 50px">

            	<table id="stable" style="width: 50%; margin: 0 auto 2em auto;" cellspacing="0" cellpadding="3" border="0">

        <tbody>
            <tr id="filter_global">
                <td>Global search</td>
                <td align="center"><input type="text" class="global_filter" id="global_filter"></td>
                <td align="center" class="cregex"><input type="checkbox" class="global_filter" id="global_regex"></td>
                <td align="center"  class="csmart"><input type="checkbox" class="global_filter" id="global_smart" checked="checked"></td>
            </tr>
            

            <tr id="filter_col2" data-column="1">
                <td>Shipment ID</td>
                <td align="center"><input type="text" class="column_filter" id="col1_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col1_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col1_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col3" data-column="2">
                <td>Name</td>
                <td align="center"><input type="text" class="column_filter" id="col2_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col2_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col2_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col4" data-column="3">
                <td>Mobile</td>
                <td align="center"><input type="text" class="column_filter" id="col3_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col3_regex"></td>
                <td align="center"class="csmart"><input type="checkbox" class="column_filter" id="col3_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col5" data-column="4">
                <td>City</td>               
                <td align="center"><select id="city">
										<option></option>
								   </select></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col4_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col4_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col6" data-column="5">
                <td>Amount</td>
                <td align="center"><input type="text" class="column_filter" id="col5_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col5_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col5_smart" checked="checked"></td>
            </tr>
            <tr >
                <td>Date From</td>
                <td align="center"><input type="text" class="datepicker" id="min" name="min"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col5_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col5_smart" checked="checked"></td>
            </tr>
            <tr >
                <td>Date To</td>
                <td align="center"><input type="text"  id="max" name="max"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col5_regex"></td>
                <td align="center" class="csmart" ><input type="checkbox" class="column_filter" id="col5_smart" checked="checked"></td>
            </tr>
             
 <tr >
                <td>Status</td>
                <td align="center"><select id="status" >
	<option></option>

</select></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col5_regex"></td>
                <td align="center" class="csmart" ><input type="checkbox" class="column_filter" id="col5_smart" checked="checked"></td>
            </tr>

        </tbody>
    </table>
            	</div>
<table id="datatble"  class="table table-striped table-bordered display" style="width:100%">
        <thead>
            <tr>
            	<th>#</th>
                <th>Code</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>City</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Status</th>
                <th>Status Date</th>

            </tr>
        </thead>
        <tbody>
        	@foreach ($shipments as $shipment)
        		<tr>
        		<td><input type="checkbox" class="global_filter" id="global_regex" value="{{$shipment->id}}"></td>
                <td>{{$shipment->id}}</td>
                <td>{{$shipment->name}}</td>
                <td>{{$shipment->mobile}}</td>
                <td>{{$shipment->city_name}}</td>
                <td>{{$shipment->totalamount}}</td>
                <td>{{$shipment->created_at}}</td>
                <td>{{$shipment->status_name}}</td>
                <td>{{$shipment->cby}}</td>
                
            </tr>
        	@endforeach
            
        </tbody>
    </table>
    

</div>
<select id="status">
	<option></option>

</select>
<select id="city">
	<option></option>
</select>
<div class="box-footer">
  <input type="submit" name="submit" value="  تعديل" class="btn btn-success btn-lg pull-right  ">
  </div>


</div>
<form role="form" method="POST" action="{{ route('shipments.store') }}" enctype="multipart/form-data">
	
	@csrf
	<input type="file" name="your_file">
	<input type="submit" name="submit">
</form>
@stop
@section('js')

<script >
	$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = parseInt( $('#min').val(), 10 );
        var max = parseInt( $('#max').val(), 10 );
        var amount = parseFloat( data[5] ) || 0; // use data for the age column
 
        if ( ( isNaN( min ) && isNaN( max ) ) ||
             ( isNaN( min ) && amount <= max ) ||
             ( min <= amount   && isNaN( max ) ) ||
             ( min <= amount   && amount <= max ) )
        {
            return true;
        }
        return false;
    }
);
	function filterGlobal () {
    $('#datatble').DataTable().search(
        $('#global_filter').val(),
        $('#global_regex').prop('checked'),
        $('#global_smart').prop('checked')
    ).draw();
}
 
function filterColumn ( i ) {
    $('#datatble').DataTable().column( i ).search(
        $('#col'+i+'_filter').val(),
        $('#col'+i+'_regex').prop('checked'),
        $('#col'+i+'_smart').prop('checked')
    ).draw();
}
 
$(document).ready(function() {
    $('#datatble').DataTable({
        "scrollX": true,
         dom: 'lBfrtip',
         buttons: [
            'copy',
            'csv',
            'excel',
            'pdf',
            'print'
        ],
        select: true, "order": [[ 0, "desc" ]],
        
       

});
    $('.rsell', this).css('background-color')
    var table = $('#advtable').DataTable();
 
    $('#advtable tbody').on( 'click', 'tr', function () {
        $(this).toggleClass('selected');
    } );
 
    $('input.global_filter').on( 'keyup click', function () {
        filterGlobal();
    } );
 
    $('input.column_filter').on( 'keyup click', function () {
        filterColumn( $(this).parents('tr').attr('data-column') );
    } );
     $('#min, #max').keyup( function() {
        $('#datatble').DataTable().draw();
    } );
     var table = $('#datatble').DataTable();

     table.columns(4).indexes().flatten().each( function ( i ) {
    var column = table.column( i );
    var select = $('#city')
        
        .on( 'change', function () {
           
            var val = $.fn.dataTable.util.escapeRegex(
                $(this).val()
            );
 
            column
                .search( val ? '^'+val+'$' : '', true, false )
                .draw();
        } );
 
    column.data().unique().sort().each( function ( d, j ) {
        select.append( '<option value="'+d+'">'+d+'</option>' )
    } );
} );
 
table.columns(7).indexes().flatten().each( function ( i ) {
    var column = table.column( i );
    var select = $('#status')
        
        .on( 'change', function () {
           
            var val = $.fn.dataTable.util.escapeRegex(
                $(this).val()
            );
 
            column
                .search( val ? '^'+val+'$' : '', true, false )
                .draw();
        } );
 
    column.data().unique().sort().each( function ( d, j ) {
        select.append( '<option value="'+d+'">'+d+'</option>' )
    } );
} );
} );
	

	
</script>
@stop
@push('js')
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
        <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4',format: 'yyyy-mm-dd'
        });
                $('#datepicker1').datepicker({
            uiLibrary: 'bootstrap4',format: 'yyyy-mm-dd' 
        });
    </script>

  

       <script src="https://code.jquery.com/jquery-3.3.1.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js" type="text/javascript"></script>


      <script src=" https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/select/1.3.0/js/dataTables.select.min.js" type="text/javascript"></script>




@endpush
@push('css')
<style type="text/css">
	#datatble_filter{display: none}
	#datatble_length{float: right;}
	.cregex,.csmart{display: none}
	#stable tr td {font-weight: bold}
	#stable tr td input , #stable tr td select{width: 200px}
</style>
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
<link href=" https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css" rel="stylesheet">

    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">



@endpush