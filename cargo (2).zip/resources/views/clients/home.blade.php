@extends('adminlte::page')

@section('content')
<div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>{{$wallet->sum('amount')}}</h3>

              <p>Balance</p>
            </div>
            <div class="icon">
              <i class="ion ion-cash"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>{{$shipments->count()}}</h3>

              <p>Shipments </p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>{{$completed->count()}}</h3>

              <p>Completed Shippments</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>{{$shipments->count()*$completed->count()/100}}<sup style="font-size: 20px">%</sup></h3>

              <p>Success Rate</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
<div class="box box-warning" >
            <div class="box-header with-border" >
                 @if ($shipmentsa->count()>0)
                <a href="{{ route('client.create') }}"  style="margin:0px 3px" class="btn  btn-danger pull-right">
             <span>Missing City</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-red" >{{$shipmentsa->count()}}</small>
            </span>
          </a>
                   
                @endif
               <button type="button" class="btn btn-box-tool" data-widget="collapse"><h3 class="box-title">Shipments</h3>
                </button>
          
                <button class="btn  btn-info pull-right" type="button" data-toggle="collapse" data-target="#searchdiv" aria-expanded="false" aria-controls="searchdiv" style="margin:0px 3px"><h3 class="box-title" ><i class="ion ion-search"></i></h3></button>
                <button type="button" style="margin:0px 3px" class="btn  btn-warning pull-right" id="print"><h3 class="box-title"><i class="ion ion-printer"></i></h3>
                </button>
               
                 
             
            </div>
            @if($errors->count()>0)
            <div class="callout callout-danger">
                           


               @foreach ($errors->all() as $error)
              
             <h4>{{ $error }}</h4>
              @endforeach
              </div>
            @endif
            <div class="box-body">

                <div class="col-lg-12 text-center " style=" margin-bottom: 50px  ">
                    <h1 class="text-center " style="margin:auto ; display: inline-block;">Here Where <b class="text-yellow">YOU</b> Can , </h1><h1><b>CREATE</b>,<b>MANAGE </b>& <b>TRACK </b></h1><h1>Your Orders </h1>
                </div>

            	<div class="col-lg-12  collapse" id="searchdiv" style="border-bottom: black 1px solid; margin-bottom: 50px">

            	<table id="stable" style="width: 50%; margin: 0 auto 2em auto;" cellspacing="0" cellpadding="3" border="0">

        <tbody>
            <tr id="filter_global">
                <td>Global search</td>
                <td align="center"><input type="text" class="global_filter" id="global_filter"></td>
                <td align="center" class="cregex"><input type="checkbox" class="global_filter" id="global_regex"></td>
                <td align="center"  class="csmart"><input type="checkbox" class="global_filter" id="global_smart" checked="checked"></td>
            </tr>
            

            <tr id="filter_col1" data-column="0">
                <td>Shipment ID</td>
                <td align="center"><input type="text" class="column_filter" id="col0_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col0_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col0_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col2" data-column="1">
                <td>Name</td>
                <td align="center"><input type="text" class="column_filter" id="col1_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col1_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col1_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col3" data-column="2">
                <td>Mobile</td>
                <td align="center"><input type="text" class="column_filter" id="col2_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col2_regex"></td>
                <td align="center"class="csmart"><input type="checkbox" class="column_filter" id="col2_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col4" data-column="3">
                <td>City</td>               
                <td align="center"><select id="city">
										<option></option>
								   </select></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col3_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col3_smart" checked="checked"></td>
            </tr>
            <tr id="filter_col5" data-column="4">
                <td>Amount</td>
                <td align="center"><input type="text" class="column_filter" id="col4_filter"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col4_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col4_smart" checked="checked"></td>
            </tr>
            <tr >
                <td>Date From</td>
                <td align="center"><input type="text" class="datepicker" id="min" name="min"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col5_regex"></td>
                <td align="center" class="csmart"><input type="checkbox" class="column_filter" id="col5_smart" checked="checked"></td>
            </tr>
            <tr >
                <td>Date To</td>
                <td align="center"><input type="text"  id="max" name="max"></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col5_regex"></td>
                <td align="center" class="csmart" ><input type="checkbox" class="column_filter" id="col5_smart" checked="checked"></td>
            </tr>
             
 <tr >
                <td>Status</td>
                <td align="center"><select id="status" >
	<option></option>

</select></td>
                <td align="center"  class="cregex"><input type="checkbox" class="column_filter" id="col5_regex"></td>
                <td align="center" class="csmart" ><input type="checkbox" class="column_filter" id="col5_smart" checked="checked"></td>
            </tr>

        </tbody>
    </table>
            	</div>
                 <div class="row ">
        <div class="col-xs-12  text-center " style="margin:auto;display: inline-block;margin-bottom:50px" >
          <div class="card " >
           
            <div class="card-body" >
              <button type="button" class="btn bg-black btn-lg" data-toggle="modal" data-target="#singleship">
                <i class="fas fa-box"></i>
                Single Shipment
              </button>
              
              <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#multiship">
                Bulk Shipments<i class="fas fa-boxes"></i>
              </button>
             
            </div>
          </div>
        </div>
      </div>
      <form  target="_blank" method="post" action="{{ route('client.store') }}">
        @csrf
        
<table id="datatble"  class="table table-striped table-bordered display" style="width:100%">
        <thead>
            <tr>
            	
                <th>Code</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>City</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Status</th>
                <th>Status Date</th>
                <th><i class="ion ion-printer"></i></th>

            </tr>
        </thead>
        <tbody>
        	@foreach ($shipments as $shipment)
        		<tr>
        		
                <td><a href="{{ route('client.show',$shipment->id) }}"> {{$shipment->id}}</a></td>
                <td>{{$shipment->name}}</td>
                <td>{{$shipment->mobile}}</td>
                <td>{{$shipment->city_name}}</td>
                <td>{{$shipment->totalamount}}</td>
                <td>{{$shipment->created_at}}</td>
                <td>{{$shipment->stats->last()->status_name}}</td>
                <td>{{$shipment->stats->last()->created_at}}</td>
                <td><input type="checkbox" class="global_filter" name="shipments[]" id="global_regex" value="{{$shipment->id}}"></td>
                
            </tr>
        	@endforeach
            
        </tbody>
    </table>
    

</div>

<div class="box-footer">
  <input type="submit" name="submit" value="  Print" class="btn btn-warning btn-lg pull-right  ">
  </div>
</form>

</div>

<div class="modal fade" id="multiship">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Bulk Shipments</h4>
              </div>
              <form role="form" method="POST" action="{{ route('uploadship') }}" enctype="multipart/form-data">
                @csrf
              <div class="modal-body">
                <ul>
                  <li>Download shipments sheet <a href="{{ asset('shipments.xlsx') }}">Click To Download</a></li>
                  <li>Fill it with your orders</li>
                  <li>Upload it here</li>
                  <li>We will add some spped to your deliveries</li>
                </ul>  
                 <div class="form-group">
                  
                  <input type="file" id="exampleInputFile" name="your_file">

                  
                </div>
              </div>
              <div class="modal-footer">
                <input type="submit" class="btn btn-warning" value="upload ">
               
              </div>
          </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <div class="modal fade" id="singleship">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Single Shipment</h4>
              </div>
              <form role="form" method="post" action="{{ route('createsingle') }}">
                @csrf
                
              <div class="modal-body">
                <div class="form-group">
                  <label >Name</label>
                  <input type="text" class="form-control" required="required" name="name">
                </div>
                <div class="form-group">
                  <label >Mobile</label>
                  <input type="text" class="form-control" required="required" name="mobile">
                </div>
                <div class="form-group">
                  <label >Amount</label>
                  <input type="text" class="form-control" required="required" name="amount">
                </div>
                <div class="form-group">
                  <label >City</label>
                 <select class="form-control" name="city">
                   <option>Select City</option>
                   @foreach ($cities as $city)
                   <option value="{{$city->name}}">{{$city->name}}</option>  
                   @endforeach
                 </select>
                </div>
                <div class="form-group">
                  <label >District</label>
                  <input type="text" class="form-control" required="required" name="district">
                </div>
                <div class="form-group">
                  <label >Address</label>
                  <input type="text" class="form-control" required="required" name="address">
                </div>
                <div class="form-group">
                  <label >Note</label>
                  <input type="text" class="form-control" name="note">
                </div>
                
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <input type="submit" value="Create"class="btn btn-success">
              </div>
            </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
@stop
@section('js')

<script >
	$.fn.dataTableExt.afnFiltering.push(
    function( oSettings, aData, iDataIndex ) {
        var iFini = document.getElementById('min').value;
        var iFfin = document.getElementById('max').value;
        var iStartDateCol = 5;
        var iEndDateCol = 5;
 
        iFini=iFini.substring(6,10) + iFini.substring(3,5)+ iFini.substring(0,2);
        iFfin=iFfin.substring(6,10) + iFfin.substring(3,5)+ iFfin.substring(0,2);
 
        var datofini=aData[iStartDateCol].substring(6,10) + aData[iStartDateCol].substring(3,5)+ aData[iStartDateCol].substring(0,2);
        var datoffin=aData[iEndDateCol].substring(6,10) + aData[iEndDateCol].substring(3,5)+ aData[iEndDateCol].substring(0,2);
 
        if ( iFini === "" && iFfin === "" )
        {
            return true;
        }
        else if ( iFini <= datofini && iFfin === "")
        {
            return true;
        }
        else if ( iFfin >= datoffin && iFini === "")
        {
            return true;
        }
        else if (iFini <= datofini && iFfin >= datoffin)
        {
            return true;
        }
        return false;
    }
);
	function filterGlobal () {
    $('#datatble').DataTable().search(
        $('#global_filter').val(),
        $('#global_regex').prop('checked'),
        $('#global_smart').prop('checked')
    ).draw();
}
 
function filterColumn ( i ) {
    $('#datatble').DataTable().column( i ).search(
        $('#col'+i+'_filter').val(),
        $('#col'+i+'_regex').prop('checked'),
        $('#col'+i+'_smart').prop('checked')
    ).draw();
}
 
$(document).ready(function() {
    $('#datatble').DataTable({
        "scrollX": true,
         dom: 'lBfrtip',
         buttons: [
            'copy',
            'csv',
            'excel',
            'pdf',
            'print'
        ],
        select: true, "order": [[ 0, "desc" ]],
        
       

});
     $('#print').on( 'click', function (e) {
      
 
        // Get the column API object
        var column = table.column(8);
 
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
    $('.rsell', this).css('background-color')
    var table = $('#advtable').DataTable();
 
    $('#advtable tbody').on( 'click', 'tr', function () {
        $(this).toggleClass('selected');
    } );
 
    $('input.global_filter').on( 'keyup click', function () {
        filterGlobal();
    } );
 
    $('input.column_filter').on( 'keyup click', function () {
        filterColumn( $(this).parents('tr').attr('data-column') );
    } );
     $('#min, #max').keyup( function() {
        $('#datatble').DataTable().draw();
    } );
     var table = $('#datatble').DataTable();

     table.columns(3).indexes().flatten().each( function ( i ) {
    var column = table.column( i );
    var select = $('#city')
        
        .on( 'change', function () {
           
            var val = $.fn.dataTable.util.escapeRegex(
                $(this).val()
            );
 
            column
                .search( val ? '^'+val+'$' : '', true, false )
                .draw();
        } );
 
    column.data().unique().sort().each( function ( d, j ) {
        select.append( '<option value="'+d+'">'+d+'</option>' )
    } );
} );
 
table.columns(6).indexes().flatten().each( function ( i ) {
    var column = table.column( i );
    var select = $('#status')
        
        .on( 'change', function () {
           
            var val = $.fn.dataTable.util.escapeRegex(
                $(this).val()
            );
 
            column
                .search( val ? '^'+val+'$' : '', true, false )
                .draw();
        } );
 
    column.data().unique().sort().each( function ( d, j ) {
        select.append( '<option value="'+d+'">'+d+'</option>' )
    } );
} );
} );
	

	
</script>
@stop
@push('js')
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
        <script>
        $('#min').datepicker({
            uiLibrary: 'bootstrap4',format: 'yyyy-mm-dd',

        });
                $('#max').datepicker({
            uiLibrary: 'bootstrap4',format: 'yyyy-mm-dd' 
        });
    </script>

  

       <script src="https://code.jquery.com/jquery-3.3.1.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js" type="text/javascript"></script>


      <script src=" https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js" type="text/javascript"></script>


       <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js" type="text/javascript"></script>


       <script src="https://cdn.datatables.net/select/1.3.0/js/dataTables.select.min.js" type="text/javascript"></script>




@endpush
@push('css')
<style type="text/css">
	#datatble_filter{display: none}
	#datatble_length{float: right;}
	.cregex,.csmart{display: none}
	#stable tr td {font-weight: bold}
	#stable tr td input , #stable tr td select{width: 200px}
	.input-group-append{position: absolute !important;}
	.input-group-append button{background-color: white; height:30px}
	.input-group-append button i{padding: auto}
</style>
<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
<link href=" https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css" rel="stylesheet">

    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">



@endpush