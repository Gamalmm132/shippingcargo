@extends('adminlte::master')

@section('adminlte_css')
    <link rel="stylesheet" href="{{ asset('vendor/adminlte/vendor/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    @yield('css')
    <style type="text/css">
        body{background:white !important;}
        .pace{display: none !important}

    </style>
@stop



@section('body')

@foreach ($shipments as $shipment)
	{{-- expr --}}

<div class="wrapper" style="page-break-after:always;">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-13">
        <h3 class="page-header">
          <img  src="{{ asset('logo.png') }}" style="height: 30px">
          <small class="pull-right"><b>#{{$shipment->id}}</b></small>
        </h3>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row" >
      
      <!-- /.col -->
      <div class="col-sm-8 col-lg-9 " >
       
        <div class="table-responsive" >
          <table class="table col-lg-12" style="table-layout: fixed;">
            <tr>
            	<tr>
              <th>From</th>
              <td colspan="3">{{$shipment->cby}}</td>
            </tr>
            <tr>
              <th>To</th>
              <td colspan="3">{{$shipment->name}}</td>
            </tr>
              <th >Address:</th>
              <td colspan="3">{{$shipment->address}}</td>
            </tr>
            <tr>
              <th>District</th>
              <td>{{$shipment->district}}</td>
                  <th>City:</th>
              <td>{{$shipment->city_name}}</td>
            </tr>
            <tr>
              <th>Mobile:</th>
              <td colspan="3">{{$shipment->mobile}}</td>
            </tr>
            <tr>
              <th>Description:</th>
              <td colspan="3">{{$shipment->comment}}</td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.col -->
      <div class="col-sm-3 col-lg-3 invoice-col pull-right">
        {!! QrCode::size(200)->generate($shipment->id); !!}
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->
 
    <!-- /.row -->

    <div class="row">
      <!-- accepted payments column -->
      <div class="col-xs-6">
        <p class="lead"><b>Signature:</b></p>
        
      </div>
      <!-- /.col -->
      <div class="col-xs-6">
        <p class="lead"><b>Amount:{{$shipment->totalamount}}</b></p>

        
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
@endforeach

@stop
<script type="text/javascript"> 

  window.addEventListener("ready", window.print());
</script>