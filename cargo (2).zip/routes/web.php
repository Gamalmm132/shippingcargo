<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect(route('login'));
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();
Route::get('/client', 'ClientController@index');
Route::get('/home', 'HomeController@index')->name('home');
Route::group(['middleware' => 'admin'], function()
{
Route::resources([

   

    'shipments' => 'ShipmentController',
    'client' => 'ClientController',
    
    'manageclients'=>'ManageusersController',
    'manage/cities'=>'CityController',
    'shipments'=>'ShipmentController',
    'statusname'=>'StatusnameController',
    'statushipments'=>'StatusshipmentController',
    'payments'=>'PaymentrequestController',
    'zones'=>'ZoneController',
    'profits'=>'ProfitController',

]);
Route::resource('profile' ,'ProfileController')->parameters([
    'profile' => 'user'
]);
});


Route::post('/profile/{id}', 'ProfileController@edit')->name('profile.edit')->middleware('auth');
Route::group(['middleware' => 'auth'], function()
{
Route::resources([

    'client' => 'ClientController',
    'wallet' => 'ClientwalletController',
  

]);
});
Route::post('/shipupload', 'ClientController@uploadship')->name('uploadship')->middleware('auth');
Route::post('/createsingle', 'ClientController@createsingle')->name('createsingle')->middleware('auth');

Route::get('/cities/fees', 'ClientController@cityrate')->name('cityrates')->middleware('auth');
Route::get('/profile', 'ClientController@viewprofile')->name('viewprofile')->middleware('auth');
Route::post('/editprofile', 'ClientController@editprofile')->name('editprofile')->middleware('auth');
Route::post('/changepass', 'ClientController@changepass')->name('changepass')->middleware('auth');


Route::resources([

    'securehide' => 'CourierController',
    
  

]);
