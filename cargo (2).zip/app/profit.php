<?php

namespace App;
use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class profit extends Model
{
    
      public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            $my_model->id = uniqid();
            $my_model->cby = Auth::id();
            $my_model->uby = Auth::id();
        });
         self::updating(function ($my_model) {
            $my_model->uby = Auth::id();
        });
    }
    protected $fillable = [
        'id','shipment_id','request_id','cashout_id','totalamount', 'useramount','companyamount','requestamount','cashoutamount','user_id','status', 'comment','type','uby', 'cby','collected_by','collected_at','collected','transferred','transferred_by','transferred_at'
    ];


       protected $casts = [
       
        'id' => 'string'
    ];
    use SoftDeletes;
    protected $dates = ['deleted_at'];
     public function cbyn()
{
    return $this->belongsTo('App\user','cby')->withDefault(['name'=>NULL]);
}
 public function ubyn()
{
    return $this->belongsTo('App\user','uby')->withDefault(['name'=>NULL]);
}
 public function collecs()
{
    return $this->belongsTo('App\user','collected_by')->withDefault(['name'=>NULL]);
}
public function sendes()
{
    return $this->belongsTo('App\user','sender_id')->withDefault(['name'=>NULL]);
}
 public function transfs()
{
    return $this->belongsTo('App\user','transferred_by')->withDefault(['name'=>NULL]);
}
}
