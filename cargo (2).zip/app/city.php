<?php

namespace App;
use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class city extends Model
{
  public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            $my_model->id = uniqid();
            $my_model->cby = Auth::id();
            $my_model->uby = Auth::id();
        });
         self::updating(function ($my_model) {
            $my_model->uby = Auth::id();
        });
    }
    protected $fillable = [
        'id','name','fees', 'cby','zone_id','zone_name','uby'
    ];
       protected $casts = [
       
        'id' => 'string'
    ];
    use SoftDeletes;
    protected $dates = ['deleted_at'];
     public function zon()
{
    return $this->belongsTo('App\zone','zone_id')->withDefault(['name'=>NULL]);
}
    
}
