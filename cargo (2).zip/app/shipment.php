<?php

namespace App;

use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class shipment extends Model
{
      public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            $my_model->uby = Auth::id();
            $my_model->cby = Auth::id();
        });
         self::updating(function ($my_model) {
            $my_model->uby = Auth::id();
        });
    }
    protected $fillable = [
        'id','name','mobile','city_id','city_name', 'district','address','totalamount','fees','netamount','status_id', 'status_name','comment','courier_name','courier_id','cash_collected','cash_collected_by', 'cby','sender_id','uby'
    ];


       protected $casts = [
       
        'id' => 'string'
    ];
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    public function stats()
    {
        return $this->hasMany('App\statusshipment');
    }
     public function cbyn()
{
    return $this->belongsTo('App\user','cby')->withDefault(['name'=>NULL]);
}
  public function profs()
    {
        return $this->hasOne('App\profit');
    }
    public function wallets()
    {
        return $this->hasOne('App\wallet');
    }
}
