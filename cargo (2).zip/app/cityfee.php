<?php

namespace App;
use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class cityfee extends Model
{
    public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            $my_model->id = uniqid();
            $my_model->cby = Auth::id();
            $my_model->uby = Auth::id();
        });
        self::updating(function ($my_model) {
            $my_model->uby = Auth::id();
        });
    }
    protected $fillable = [
        'id','city_id','city_name','user_id','fees', 'cby','uby'
    ];
       protected $casts = [
       
        'id' => 'string'
    ];
     use SoftDeletes;
    protected $dates = ['deleted_at'];
}
