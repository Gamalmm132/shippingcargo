<?php

namespace App;

use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class statusshipment extends Model
{
    public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            $my_model->id = uniqid();
            $my_model->cby = Auth::id();
        });
    }
    protected $fillable = [
        'id','shipment_id','status_id','status_name','comment',  'cby',
    ];


       protected $casts = [
       
        'id' => 'string'
    ];
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    
    public function cbyn()
{
    return $this->belongsTo('App\user','cby')->withDefault(['name'=>NULL]);
}
}
