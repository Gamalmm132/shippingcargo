<?php

namespace App;

use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class wallet extends Model
{
	 public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            $my_model->id = uniqid();
            $my_model->cby = Auth::id();
            $my_model->uby = Auth::id();
        });
    }
    protected $fillable = [
        'id','shipment_id','amount','collected','collected_at',  'cby','collected_by','type','uby','client_id','transferred','transferred_by','transferred_at'
    ];


       protected $casts = [
       
        'id' => 'string'
    ];
    use SoftDeletes;
    protected $dates = ['deleted_at'];
    
}
