<?php

namespace App;
use Auth;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class profile extends Model
{
    public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            $my_model->id = uniqid();
            $my_model->cby = Auth::id();
            $my_model->uby = Auth::id();
        });
        self::updating(function ($my_model) {
            $my_model->uby = Auth::id();
        });
    }

    protected $fillable = [
        'id','user_id', 'shipping_code','bank_name','bank_account','address','mobile','cby','city_id','district','shippment_count','page_name','uby'
    ];

       protected $casts = [
       
        'id' => 'string'
    ];
      use SoftDeletes;
    protected $dates = ['deleted_at'];
    
    
}