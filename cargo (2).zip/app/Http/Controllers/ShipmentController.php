<?php

namespace App\Http\Controllers;

use App\Imports\shipmentimport;
use Maatwebsite\Excel\Facades\Excel;
use App\{shipment,statusshipment,profit,city,cityfee};
use Illuminate\Http\Request;

class ShipmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   $shipments=shipment::all();
        $cities=city::all();
         return view('dash.shipments.home',compact('shipments','cities'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
    }

    public function storei(Request $request)
    {
       Excel::import(new shipmentimport, request()->file('your_file'));
       return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function show(shipment $shipment)
    {
        $status= statusshipment::where('shipment_id',$shipment->id)->get();
        $collecs=profit::where('shipment_id',$shipment->id)->first();
        $cities=city::all();
        return view('dash.shipments.shipdetails',compact('shipment','status','collecs','cities'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function edit(shipment $shipment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, shipment $shipment)
        {  $city=cityfee::where('city_id',$request->city)->where('user_id',$shipment->sender_id)->first();

            $netamount=$request->totalamount-$city->fees;
           $shipment->update($request->all()+['city_name'=>$city->city_name,'fees'=>$city->fees,'netamount'=>$netamount]);
           return back();
        }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function destroy(shipment $shipment)
    {
        //
    }
}
