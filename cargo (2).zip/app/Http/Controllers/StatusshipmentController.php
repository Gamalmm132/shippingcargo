<?php

namespace App\Http\Controllers;

use App\{statusshipment,shipment,statusname,wallet,profit};
use Illuminate\Http\Request;

class StatusshipmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $shipments=shipment::whereNotIn('status_name',['refused','delivered'])->where('city_name','!=','na')->get();
        $statuses=statusname::all();
        return view('dash.shipments.editstat',compact('shipments','statuses'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        foreach ($request->stat as $key => $value) {
            if ($value !='5dc8ae678a427') {
                # code...
            
           $shipments=shipment::find($key);
           $statusname=statusname::find($value);
            statusshipment::create([
                'shipment_id'=>$shipments->id,
                'status_id'=>$value,
                'status_name'=>$statusname->name,
                'comment'=>$request->comment[$key]
            ]);
            $shipments->update(['status_id'=>$value,
                'status_name'=>$statusname->name]);
            if ($value == '5dc8d17802933') {
                wallet::create([
                'shipment_id'=>$shipments->id,
                'amount'=>$shipments->netamount,
                'type'=>'cash',
                'client_id'=>$shipments->sender_id,                
                ]);
                profit::create([
                'shipment_id'=>$shipments->id,
                'totalamount'=>$shipments->totalamount ,
                'useramount'=>$shipments->netamount ,
                'companyamount'=>$shipments->fees ,
                'user_id'=>$shipments->sender_id ,                
                'type'=>'delivered',                
                ]);
            }elseif ($value == '5dc8d181b5fd9') {
                wallet::create([
                'shipment_id'=>$shipments->id,
                'amount'=>'-'.$shipments->fees,
                'type'=>'fees', 
                'client_id'=>$shipments->sender_id ,                
                ]);
                profit::create([
                'shipment_id'=>$shipments->id,
                'totalamount'=>0,
                'useramount'=>0,
                'companyamount'=>$shipments->fees ,
                'user_id'=>$shipments->sender_id ,                
                'type'=>'refused',                
                ]);
            }
        }
        }
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\statusshipment  $statusshipment
     * @return \Illuminate\Http\Response
     */
    public function show(statusshipment $statusshipment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\statusshipment  $statusshipment
     * @return \Illuminate\Http\Response
     */
    public function edit(statusshipment $statusshipment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\statusshipment  $statusshipment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, statusshipment $statusshipment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\statusshipment  $statusshipment
     * @return \Illuminate\Http\Response
     */
    public function destroy(statusshipment $statusshipment)
    {
        //
    }
}
