<?php

namespace App\Http\Controllers;

use App\{city,user,cityfee,zone};
use Illuminate\Http\Request;

class CityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cit=city::all();
        $zones=zone::all();
        return view('dash.cities.view',compact('cit','zones'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
        
            }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        city::create($request->all()); 
        $users=user::where('status','activated')->where('type','user')->get();
        $city=city::where('name',$request->name)->first();
        foreach ($users as $user) {
            cityfee::create(['city_id'=>$city->id,'city_name'=>$city->name,'user_id'=>$user->id,'fees'=>$city->fees]);
        }
        return redirect()->route('cities.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\city  $city
     * @return \Illuminate\Http\Response
     */
    public function show(city $city)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\city  $city
     * @return \Illuminate\Http\Response
     */
    public function edit(city $city)
    {
     $zones=zone::all();
     return view('dash.cities.edit',compact('city','zones'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\city  $city
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, city $city)
    {
        $city->update($request->all());
       
        return redirect()->route('cities.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\city  $city
     * @return \Illuminate\Http\Response
     */
    public function destroy(city $city)
    {
        $city->delete();
        return redirect()->route('cities.index');
    }
}
