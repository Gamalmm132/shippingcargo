<?php

namespace App\Http\Controllers;

use App\statusname;
use Illuminate\Http\Request;

class StatusnameController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $statusname=statusname::all();
        return view('dash.statuses.view',compact('statusname'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $statuses=statusname::create($request->all()); 
        return redirect()->route('statusname.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\statusname  $statusname
     * @return \Illuminate\Http\Response
     */
    public function show(statusname $statusname)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\statusname  $statusname
     * @return \Illuminate\Http\Response
     */
    public function edit(statusname $statusname)
    {
       return view('dash.statuses.edit',compact('statusname'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\statusname  $statusname
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, statusname $statusname)
    {
         $statusname->update($request->all());
       
        return redirect()->route('statusname.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\statusname  $statusname
     * @return \Illuminate\Http\Response
     */
    public function destroy(statusname $statusname)
    {
        $statusname->delete();
        return redirect()->route('statusname.index');    }
}
