<?php

namespace App\Http\Controllers;

use App\zone;
use Illuminate\Http\Request;

class ZoneController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $zones=zone::all();
        return view('dash.zones.view',compact('zones'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function show(zone $zone)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function edit(zone $zone)
    {
        return view('dash.zones.edit',compact('zone'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, zone $zone)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\zone  $zone
     * @return \Illuminate\Http\Response
     */
    public function destroy(zone $zone)
    {
        //
    }
}
