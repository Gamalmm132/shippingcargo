<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\{user,city,profile,cityfee,zone};
use Auth;

class ManageusersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users=user::where('type','user')->get();
        return view('dash.clients.home',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cities = zone::all();
        $client=user::find($id);
        return view('dash.clients.activation',compact('cities','client'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $client=user::find($id);
       
       
       $client->update(["status"=>'activated','approved_by'=>Auth::id()]);
       foreach ($request->fees as $key => $value) {
           $city=city::where('zone_id',$key)->get();
           foreach ($city as $cit ) {
            cityfee::create(["city_id"=>$cit->id,
            "city_name"=>$cit->name,
            "user_id"=>$id,
            "fees"=>$value
           ]);
           }
           

       }
       profile::create(["user_id"=>$client->id,
            "shipping_code"=>$request->shipping_code,
           ]); 
         return redirect()->route('manageclients.index');
    } 

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
