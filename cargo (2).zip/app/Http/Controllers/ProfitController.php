<?php

namespace App\Http\Controllers;

use App\profit;
use Illuminate\Http\Request;

class ProfitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $profits=profit::all();
        $topay=profit::where('collected',1)->where('transferred',0)->get();
        $tocoll=profit::where('collected',0)->where('transferred',0)->get();
        return view('dash.profits.home',compact('profits','topay','tocoll'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        profit::create($request->all()+['type'=>'cashout','collected'=>1,'transferred'=>1]);
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\profit  $profit
     * @return \Illuminate\Http\Response
     */
    public function show(profit $profit)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\profit  $profit
     * @return \Illuminate\Http\Response
     */
    public function edit(profit $profit)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\profit  $profit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, profit $profit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\profit  $profit
     * @return \Illuminate\Http\Response
     */
    public function destroy(profit $profit)
    {
        //
    }
}
