<?php

namespace App\Http\Controllers;

use App\{paymentrequest,shipment,profit,wallet};
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PaymentrequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $shipments=shipment::whereIn('status_id',['5dc8d17802933','5dc8d181b5fd9'])->whereIn('status_name',['delivered','refused'])->where('cash_collected',0)->get();
         return view('dash.shipments.cashcollect',compact('shipments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $shipments=profit::where('collected',1)->where('transferred',0)->get();
         return view('dash.shipments.cashtransfer',compact('shipments'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       foreach ($request->shipments as $key => $value) {
           $shipment=shipment::find($value)->update([
            'cash_collected'=>1,
            'cash_collected_by'=>Auth::id()]);
           $wallet=wallet::where('shipment_id',$value)->update([
            'collected'=>1,
            'collected_at'=>Carbon::now(),
            'collected_by'=>Auth::id(),

           ]);
           $profit=profit::where('shipment_id',$value)->update([
            'collected'=>1,
            'collected_at'=>Carbon::now(),
            'collected_by'=>Auth::id(),

           ]);
       }
       return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\paymentrequest  $paymentrequest
     * @return \Illuminate\Http\Response
     */
    public function show(paymentrequest $paymentrequest)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\paymentrequest  $paymentrequest
     * @return \Illuminate\Http\Response
     */
    public function edit(paymentrequest $paymentrequest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\paymentrequest  $paymentrequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, paymentrequest $paymentrequest)
    {
        foreach ($request->shipments as $key => $value) {
            $wallet=wallet::where('shipment_id',$value)->update([
            'transferred'=>1,
            'transferred_at'=>Carbon::now(),
            'transferred_by'=>Auth::id(),

           ]);
           $profit=profit::where('shipment_id',$value)->update([
            'transferred'=>1,
            'transferred_at'=>Carbon::now(),
            'transferred_by'=>Auth::id(),

           ]);
        }
        return back()->with('success','Cash Transferred Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\paymentrequest  $paymentrequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(paymentrequest $paymentrequest)
    {
        //
    }
}
