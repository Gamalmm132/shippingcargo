<?php

namespace App\Http\Controllers;

use Auth;
use App\Imports\shipmentimport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\{cityfee,shipment,wallet,statusshipment,city,profile,user};
class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   $shipmentsa=shipment::where('cby',Auth::id())->where('city_name','na')->get();
        
        $shipments=shipment::where('cby',Auth::id())->get();
        $wallet=wallet::where('client_id',Auth::id())->where('collected',1)->where('transferred',0)->get();
        $completed=shipment::where('cby',Auth::id())->where('status_name','delivered')->get();
        $cities=city::all();
        return view('clients.home',compact('shipments','shipmentsa','wallet','completed','cities'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $shipments=shipment::where('cby',Auth::id())->where('city_name','na')->get();
            $cityfee=cityfee::where('user_id',Auth::id())->get();
             $wallet=wallet::where('client_id',Auth::id())->where('collected',1)->where('transferred',0)->get();
             $shipmentsa=shipment::where('cby',Auth::id())->get();
             $completed=shipment::where('cby',Auth::id())->where('status_name','delivered')->get();
            return view('clients.cityedit',compact('shipments','shipmentsa','cityfee','wallet','completed'));
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


    $arr=array_values($request->shipments);
    $shipments=shipment::find($arr);
        return view('clients.invoice',compact('shipments'));


    }


    public function  createsingle(Request $request)
    {

 $statusid='5dc8ae678a427';$statusname="preparing";
            $city=cityfee::where('city_name',$request['city'])->where('user_id',Auth::id())->first();
            $code=profile::where('user_id',Auth::id())->first();
            if($city){$cityfee =$city->fees;$cityid=$city->city_id;$netamount= $request['amount']-$city->fees;$cityname=$request['city'];}
                else{$cityid=$cityfee=$netamount=$cityname='NA';}
                $shipid=$code->shipping_code."-".uniqid();
            shipment::create([
                'id'=> $shipid,
                'name' => $request['name'],
                'mobile' => $request['mobile'],
                'city_name' => $cityname,
                'district' => $request['district'],
                'address' => $request['address'],
                'totalamount' => $request['amount'],
                'city_id'=>$cityid,
                'fees'=>$cityfee,
                'status_id'=>$statusid,
                'status_name'=>$statusname,
                'netamount'=>$netamount,
                'comment' => $request['note'],
                'sender_id' => Auth::id(),
            ]);
            statusshipment::create([
                'shipment_id'=>$shipid,
                'status_id'=>$statusid,
                'status_name'=>$statusname,
                'comment'=>$request['note']
            ]);
       return back();


    }
   

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {      $status= statusshipment::where('shipment_id',$id)->get();
        $shipment=shipment::where('id',$id)->where('cby',Auth::id())->first();
        $collecs=wallet::where('shipment_id',$shipment->id)->first();
        return view('clients.shipdetails',compact('shipment','status','collecs'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        foreach ($request->city as $key => $value) {
            $city=cityfee::where('city_id',$value)->where('user_id',$id)->first();
           $shipment= shipment::where('id',$key)->where('cby',$id)->first();
          $netamount= $shipment->totalamount-$city->fees;
            $shipment->update(['city_id'=>$city->city_id,
                      'city_name'=>$city->city_name,
                      'fees'=>$city->fees,
                      'netamount'=>$netamount,

                        ]);
        }
        return back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        foreach ($request->city as $key => $value) {
            $city=cityfee::where('city_id',$value)->where('user_id',$id)->first();
            if ($city) {
               $shipment= shipment::where('id',$key)->where('cby',$id)->first();
          $netamount= $shipment->totalamount-$city->fees;
            $shipment->update(['city_id'=>$city->city_id,
                      'city_name'=>$city->city_name,
                      'fees'=>$city->fees,
                      'netamount'=>$netamount,

                        ]);
        }
            }
            return back();
         
    }
     public function uploadship(Request $request)
    {
       Excel::import(new shipmentimport, request()->file('your_file'));
       return back();
    }

 public function cityrate()
    {  $user=user::find(Auth::id());
       $cities=cityfee::where('user_id',Auth::id())->get();
       return view('clients.cityrates',compact('cities','user'));

    }

     public function viewprofile()
    {   
        $user=user::find(Auth::id());
        $start = Carbon::now()->startOfMonth();
        $end = Carbon::now();
        $shipmentc=shipment::whereBetween('created_at', [$start, $end])->where('sender_id',Auth::id())->get();
        $wallet=wallet::where('client_id',Auth::id())->where('collected',1)->where('transferred',0)->get();
        $cities=city::all();
       return view('clients.editprofile',compact('user','shipmentc','wallet','cities'));
    }

     public function editprofile(Request $request)
    {   $profile=profile::where('user_id',Auth::id())->first();
        $profile->update($request->all());
       return redirect()->route('viewprofile')->with('success', 'Profile updated!');
    }
     public function changepass(Request $request)
    {   validator::make($request->all(), [
        'password' => ['required', 'string', 'min:8', 'confirmed'],
        ])->validate();
       return redirect()->route('viewprofile')->with('success', 'Password Changed');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
