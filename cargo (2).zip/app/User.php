<?php

namespace App;
use Auth;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public static function boot() {
        parent::boot();
        self::creating(function ($my_model) {
            
        });
        self::updating(function ($my_model) {
            $my_model->uby = Auth::id();
        });
    }
    protected $fillable = [
        'id','fname','lname', 'email', 'password', 'username','mobile','status', 'type', 'cby','approved_by','shippment_count','uby'
    ];
     
    use SoftDeletes;
    protected $dates = ['deleted_at'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'id' => 'string'
    ];
    public function profs()
    {
        return $this->hasOne('App\profile')->withDefault(['name'=>NULL]);
    }
   public function ships()
    {
        return $this->hasMany('App\shipment','cby');
    }
    public function walls()
    {
        return $this->hasMany('App\wallet');
    }
}
