<?php

namespace App\Imports;

use Auth;
use App\{shipment,city,statusshipment,profile,cityfee};
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class shipmentimport implements ToCollection, WithHeadingRow
{
    public function collection(Collection $rows)
    {
        
    
         Validator::make($rows->toArray(), [
             '*.name'=> 'required',
             '*.amount'=>['required','numeric'],
             '*.address'=>['required'],
         ])->validate();
         
        foreach ($rows as $row) {
            $statusid='5dc8ae678a427';$statusname="preparing";
            $city=cityfee::where('city_name',$row['city'])->where('user_id',Auth::id())->first();
            $code=profile::where('user_id',Auth::id())->first();
            if($city){$cityfee =$city->fees;$cityid=$city->city_id;$netamount= $row['amount']-$city->fees;$cityname=$row['city'];}
                else{$cityid=$cityfee=$netamount=$cityname='NA';}
                $shipid=$code->shipping_code."-".uniqid();
            shipment::create([
                'id'=> $shipid,
                'name' => $row['name'],
                'mobile' => $row['mobile'],
                'city_name' => $cityname,
                'district' => $row['district'],
                'address' => $row['address'],
                'totalamount' => $row['amount'],
                'city_id'=>$cityid,
                'fees'=>$cityfee,
                'status_id'=>$statusid,
                'status_name'=>$statusname,
                'netamount'=>$netamount,
                'comment' => $row['note'],
                'sender_id' => Auth::id(),
            ]);
            statusshipment::create([
                'shipment_id'=>$shipid,
                'status_id'=>$statusid,
                'status_name'=>$statusname,
                'comment'=>$row['note']
            ]);
        }
    }
}
